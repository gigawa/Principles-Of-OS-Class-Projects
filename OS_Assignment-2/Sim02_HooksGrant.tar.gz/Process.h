#ifndef PROCESS_
#define PROCESS_

#include"MetaData.h"

using namespace std;

class Process {
public:
	vector<MetaData> meta;
};

#endif
